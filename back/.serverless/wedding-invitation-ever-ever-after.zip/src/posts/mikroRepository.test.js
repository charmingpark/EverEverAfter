"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const core_1 = require("@mikro-orm/core");
const createTest_1 = require("./createTest");
const mikroEntity_1 = require("./mikroEntity");
const mikroRepository_1 = require("./mikroRepository");
let orm;
const MEMORY_NAME = ':memory:';
(0, createTest_1.createTest)('MikroPostRepository', async () => {
    const dbName = MEMORY_NAME;
    orm = await core_1.MikroORM.init({
        entities: [mikroEntity_1.PostEntity, mikroEntity_1.ImageEntity],
        dbName,
        type: 'sqlite',
    });
    if (dbName === ':memory:') {
        const generator = orm.getSchemaGenerator();
        await generator.createSchema();
    }
    const em = orm.em.fork();
    await em.createQueryBuilder(mikroEntity_1.ImageEntity).delete();
    await em.createQueryBuilder(mikroEntity_1.PostEntity).delete();
    return (0, mikroRepository_1.MikroPostRepository)(em);
}, async () => orm.close());
//# sourceMappingURL=mikroRepository.test.js.map