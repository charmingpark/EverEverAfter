"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const repository_1 = require("../comments/repository");
const repository_2 = require("./repository");
const router_1 = require("./router");
const NEW_POST = {
    message: 'test',
    images: [
        'https://pbs.twimg.com/profile_banners/1261543922309849088/1615648508/1500x500',
    ],
};
describe('posts', () => {
    it('scenario', async () => {
        const ctx = {
            commentRepo: (0, repository_1.FakeCommentRepo)([]),
            postRepo: (0, repository_2.FakePostRepo)([]),
        };
        const caller = router_1.postRouter.createCaller(ctx);
        expect(await caller.query('all')).toStrictEqual([]);
        await caller.mutation('create', NEW_POST);
        expect(await caller.query('all')).toStrictEqual([
            {
                id: 1,
                ...NEW_POST,
            },
        ]);
        await caller.mutation('modify', {
            targetId: 1,
            newMessage: 'modified',
        });
        expect(await caller.query('all')).toStrictEqual([
            {
                id: 1,
                message: 'modified',
                images: NEW_POST.images,
            },
        ]);
        await caller.mutation('delete', { targetId: 1 });
        expect(await caller.query('all')).toStrictEqual([]);
    });
});
//# sourceMappingURL=router.spec.js.map