"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTest = void 0;
const invariant_1 = require("../invariant");
const NEW_POST = {
    id: 1,
    message: 'test',
    images: [],
};
const MODIFIED_MESSAGE = '찬민아 결혼 축하해';
function createTest(label, setupRepo, teardown = async () => undefined) {
    describe(label, () => {
        afterEach(async () => {
            await teardown();
        });
        it('scenario', async () => {
            const repo = await setupRepo();
            expect(await repo.all()).toStrictEqual([]);
            await repo.add(NEW_POST);
            const data = await repo.all();
            expect(data).toMatchObject([NEW_POST]);
            (0, invariant_1.invariant)(data[0] !== undefined, '값이 존재해야한다');
            const TARGET_ID = data[0].id;
            await repo.modify({
                targetId: TARGET_ID,
                newMessage: MODIFIED_MESSAGE,
            });
            expect(await repo.all()).toMatchObject([
                {
                    id: 1,
                    message: MODIFIED_MESSAGE,
                    images: [],
                },
            ]);
            await repo.delete(TARGET_ID);
            expect(await repo.all()).toStrictEqual([]);
        });
    });
}
exports.createTest = createTest;
//# sourceMappingURL=createTest.js.map