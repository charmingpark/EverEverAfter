"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImageEntity = exports.PostEntity = void 0;
const tslib_1 = require("tslib");
const core_1 = require("@mikro-orm/core");
let PostEntity = class PostEntity {
    id;
    message;
    images = new core_1.Collection(this);
    constructor(message) {
        this.message = message;
    }
};
tslib_1.__decorate([
    (0, core_1.PrimaryKey)({ type: 'int', autoincrement: true }),
    tslib_1.__metadata("design:type", Number)
], PostEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, core_1.Property)({ type: 'text' }),
    tslib_1.__metadata("design:type", String)
], PostEntity.prototype, "message", void 0);
tslib_1.__decorate([
    (0, core_1.OneToMany)(() => ImageEntity, b => b.post),
    tslib_1.__metadata("design:type", Object)
], PostEntity.prototype, "images", void 0);
PostEntity = tslib_1.__decorate([
    (0, core_1.Entity)(),
    tslib_1.__metadata("design:paramtypes", [String])
], PostEntity);
exports.PostEntity = PostEntity;
let ImageEntity = class ImageEntity {
    id;
    src;
    post;
    constructor(src, post) {
        this.src = src;
        this.post = post;
    }
};
tslib_1.__decorate([
    (0, core_1.PrimaryKey)({ type: 'int', autoincrement: true }),
    tslib_1.__metadata("design:type", Number)
], ImageEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, core_1.Property)({ type: 'text' }),
    tslib_1.__metadata("design:type", String)
], ImageEntity.prototype, "src", void 0);
tslib_1.__decorate([
    (0, core_1.ManyToOne)({ type: 'PostEntity' }),
    tslib_1.__metadata("design:type", PostEntity)
], ImageEntity.prototype, "post", void 0);
ImageEntity = tslib_1.__decorate([
    (0, core_1.Entity)(),
    tslib_1.__metadata("design:paramtypes", [String, PostEntity])
], ImageEntity);
exports.ImageEntity = ImageEntity;
//# sourceMappingURL=mikroEntity.js.map