"use strict";
it.skip('empty', () => {
    expect(1 + 1).toBe(2);
});
//# sourceMappingURL=prismaRepository.test.js.map