"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MikroPostRepository = void 0;
const invariant_1 = require("../invariant");
const mikroEntity_1 = require("./mikroEntity");
function MikroPostRepository(em) {
    const postRepo = em.getRepository(mikroEntity_1.PostEntity);
    const imageRepo = em.getRepository(mikroEntity_1.ImageEntity);
    return {
        async has(id) {
            const result = await postRepo.count({ id });
            return result === 1;
        },
        async all() {
            const posts = await postRepo.findAll({ populate: true });
            return posts.map(post => ({
                ...post,
                images: post.images.getItems().map(image => image.src)
            }));
        },
        async add(newPost) {
            const post = new mikroEntity_1.PostEntity(newPost.message);
            const images = newPost.images.map(src => new mikroEntity_1.ImageEntity(src, post));
            imageRepo.persist(images);
            await postRepo.persistAndFlush(post);
        },
        async delete(targetId) {
            await em.createQueryBuilder(mikroEntity_1.ImageEntity)
                .delete()
                .where({ post: targetId });
            await em.flush();
            await em.createQueryBuilder(mikroEntity_1.PostEntity)
                .delete()
                .where({ id: targetId });
        },
        async modify({ targetId, newMessage }) {
            const post = await postRepo.findOne({ id: targetId });
            (0, invariant_1.invariant)(post !== null, 'post가 존재하지 않습니다');
            post.message = newMessage;
            await postRepo.flush();
        },
    };
}
exports.MikroPostRepository = MikroPostRepository;
//# sourceMappingURL=mikroRepository.js.map