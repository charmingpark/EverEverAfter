"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const createTest_1 = require("./createTest");
const repository_1 = require("./repository");
(0, createTest_1.createTest)('FakeCommentRepo', async (init) => {
    return {
        repo: (0, repository_1.FakeCommentRepo)(init),
        postId: 1,
    };
});
//# sourceMappingURL=repository.test.js.map