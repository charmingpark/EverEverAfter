"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const repository_1 = require("../posts/repository");
const repository_2 = require("./repository");
const router_1 = require("./router");
const POST_ID = 5;
describe('comments', () => {
    it('scenario', async () => {
        const caller = router_1.commentRouter.createCaller({
            postRepo: (0, repository_1.FakePostRepo)([{
                    id: POST_ID,
                    message: '찬민아 결혼 축하해',
                    images: [],
                }]),
            commentRepo: (0, repository_2.FakeCommentRepo)([])
        });
        expect(await caller.query('read', { postId: POST_ID })).toStrictEqual([]);
        await caller.mutation('create', {
            id: POST_ID,
            message: '안녕',
        });
        expect(await caller.query('read', { postId: POST_ID })).toStrictEqual([
            {
                id: 1,
                message: '안녕',
                postId: POST_ID
            },
        ]);
        await caller.mutation('update', {
            postId: POST_ID,
            commentId: 1,
            message: '바이'
        });
        expect(await caller.query('read', { postId: POST_ID })).toStrictEqual([
            {
                id: 1,
                message: '바이',
                postId: POST_ID
            },
        ]);
        await caller.mutation('delete', {
            postId: POST_ID,
            commentId: 1,
        });
        expect(await caller.query('read', { postId: POST_ID })).toStrictEqual([]);
    });
});
//# sourceMappingURL=router.spec.js.map