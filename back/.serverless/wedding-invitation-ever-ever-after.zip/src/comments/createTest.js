"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTest = void 0;
function createTest(label, setupRepo, teardown = async () => undefined) {
    describe(label, () => {
        afterEach(async () => {
            await teardown();
        });
        it('scenario', async () => {
            const { repo, postId } = await setupRepo([]);
            expect(await repo.getCommentsByPostId(postId)).toStrictEqual([]);
            await repo.addCommentToPost(postId, '안녕');
            const COMMENT_ID = 1;
            expect(await repo.getCommentsByPostId(postId)).toStrictEqual([
                { id: COMMENT_ID, message: '안녕', postId }
            ]);
            await repo.updateComment(postId, COMMENT_ID, '바이');
            expect(await repo.getCommentsByPostId(postId)).toStrictEqual([
                { id: COMMENT_ID, message: '바이', postId }
            ]);
            await repo.deleteComment(postId, COMMENT_ID);
            expect(await repo.getCommentsByPostId(postId)).toStrictEqual([]);
        });
    });
}
exports.createTest = createTest;
//# sourceMappingURL=createTest.js.map