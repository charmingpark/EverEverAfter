"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const core_1 = require("@mikro-orm/core");
const createTest_1 = require("./createTest");
const mikroEntity_1 = require("../posts/mikroEntity");
const mikroEntity_2 = require("./mikroEntity");
const mikroRepository_1 = require("./mikroRepository");
let orm;
const MEMORY_NAME = ':memory:';
(0, createTest_1.createTest)('MikroCommentRepository', async () => {
    const dbName = MEMORY_NAME;
    orm = await core_1.MikroORM.init({
        entities: [mikroEntity_1.PostEntity, mikroEntity_1.ImageEntity, mikroEntity_2.CommentEntity],
        dbName: ':memory:',
        type: 'sqlite',
    });
    if (dbName === ':memory:') {
        const generator = orm.getSchemaGenerator();
        await generator.createSchema();
    }
    const em = orm.em.fork();
    const post = await em.createQueryBuilder(mikroEntity_1.PostEntity)
        .insert({ message: 'test' });
    return {
        repo: (0, mikroRepository_1.MikroCommentRepository)(em),
        postId: post.insertId,
    };
}, async () => {
    if (orm) {
        await orm.close();
    }
});
//# sourceMappingURL=mikroRepository.test.js.map