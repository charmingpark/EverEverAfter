"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MikroCommentRepository = void 0;
const mikroEntity_1 = require("../posts/mikroEntity");
const mikroEntity_2 = require("./mikroEntity");
function MikroCommentRepository(em) {
    return {
        async getCommentsByPostId(postId) {
            const list = await em.qb(mikroEntity_2.CommentEntity)
                .select(['id', 'message'])
                .where({ post: { id: postId } })
                .execute();
            return list.map(e => ({ ...e, postId }));
        },
        async addCommentToPost(postId, message) {
            const post = em.getReference(mikroEntity_1.PostEntity, postId);
            await em.qb(mikroEntity_2.CommentEntity).insert({
                message,
                post
            });
        },
        async updateComment(postId, commentId, newMessage) {
            return em.qb(mikroEntity_2.CommentEntity)
                .update({ message: newMessage })
                .where({ id: commentId, post: { id: postId } })
                .execute();
        },
        async deleteComment(postId, commentId) {
            return em.qb(mikroEntity_2.CommentEntity)
                .delete({
                id: commentId,
                post: { id: postId }
            })
                .execute();
        },
        async deleteCommentsInPost(postId) {
            return em.qb(mikroEntity_2.CommentEntity)
                .delete({ post: { id: postId } })
                .execute();
        }
    };
}
exports.MikroCommentRepository = MikroCommentRepository;
//# sourceMappingURL=mikroRepository.js.map