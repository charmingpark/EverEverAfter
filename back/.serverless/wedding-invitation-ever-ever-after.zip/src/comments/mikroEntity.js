"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommentEntity = void 0;
const tslib_1 = require("tslib");
const core_1 = require("@mikro-orm/core");
const mikroEntity_1 = require("../posts/mikroEntity");
let CommentEntity = class CommentEntity {
    id;
    message;
    post;
    constructor(message, post) {
        this.message = message;
        this.post = post;
    }
};
tslib_1.__decorate([
    (0, core_1.PrimaryKey)({ type: 'int', autoincrement: true }),
    tslib_1.__metadata("design:type", Number)
], CommentEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, core_1.Property)({ type: 'text' }),
    tslib_1.__metadata("design:type", String)
], CommentEntity.prototype, "message", void 0);
tslib_1.__decorate([
    (0, core_1.ManyToOne)(() => mikroEntity_1.PostEntity),
    tslib_1.__metadata("design:type", Object)
], CommentEntity.prototype, "post", void 0);
CommentEntity = tslib_1.__decorate([
    (0, core_1.Entity)(),
    tslib_1.__metadata("design:paramtypes", [String, Object])
], CommentEntity);
exports.CommentEntity = CommentEntity;
//# sourceMappingURL=mikroEntity.js.map