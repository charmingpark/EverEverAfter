"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.commentRouter = void 0;
const zod_1 = require("zod");
const createRouter_1 = require("../createRouter");
const invariant_1 = require("../invariant");
const schema_1 = require("./schema");
exports.commentRouter = (0, createRouter_1.createRouter)()
    .query('read', {
    input: zod_1.z.object({
        postId: zod_1.z.number(),
    }),
    output: zod_1.z.array(schema_1.commentSchema),
    async resolve({ input: { postId }, ctx }) {
        (0, invariant_1.invariant)(await ctx.postRepo.has(postId), '404 not found');
        return ctx.commentRepo.getCommentsByPostId(postId);
    },
})
    .mutation('create', {
    input: zod_1.z.object({
        id: zod_1.z.number(),
        message: schema_1.commentSchema.shape.message,
    }),
    async resolve({ input, ctx }) {
        (0, invariant_1.invariant)(await ctx.postRepo.has(input.id), '404 not found');
        return ctx.commentRepo.addCommentToPost(input.id, input.message);
    },
})
    .mutation('update', {
    input: zod_1.z.object({
        postId: zod_1.z.number(),
        commentId: zod_1.z.number(),
        message: zod_1.z.string(),
    }),
    async resolve({ input: { postId, commentId, message }, ctx }) {
        (0, invariant_1.invariant)(await ctx.postRepo.has(postId), '404 not found');
        return ctx.commentRepo.updateComment(postId, commentId, message);
    },
})
    .mutation('delete', {
    input: zod_1.z.object({
        postId: zod_1.z.number(),
        commentId: zod_1.z.number(),
    }),
    async resolve({ input: { postId, commentId }, ctx }) {
        (0, invariant_1.invariant)(await ctx.postRepo.has(postId), '404 not found');
        return ctx.commentRepo.deleteComment(postId, commentId);
    },
});
//# sourceMappingURL=router.js.map