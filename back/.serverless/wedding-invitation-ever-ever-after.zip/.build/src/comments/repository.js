"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FakeCommentRepo = void 0;
const invariant_1 = require("../invariant");
function FakeCommentRepo(init) {
    let _fakeDB = init;
    let _count = Math.max(0, ...init.map((comment) => comment.id));
    async function _getCommentById(postId, commentId) {
        const comment = _fakeDB.find((comment) => comment.postId === postId && comment.id == commentId);
        (0, invariant_1.invariant)(comment !== undefined, `코멘트<${commentId}>가 존재하지 않습니다`);
        return comment;
    }
    return {
        async getCommentsByPostId(postId) {
            return _fakeDB.filter((comment) => comment.postId === postId);
        },
        async addCommentToPost(postId, message) {
            _count++;
            const newComment = {
                id: _count,
                message,
                postId,
            };
            _fakeDB = [..._fakeDB, newComment];
        },
        async updateComment(postId, commentId, newMessage) {
            const targetComment = await _getCommentById(postId, commentId);
            targetComment.message = newMessage;
        },
        async deleteComment(postId, commentId) {
            const targetComment = await _getCommentById(postId, commentId);
            _fakeDB = _fakeDB.filter((comment) => comment !== targetComment);
        },
        async deleteCommentsInPost(postId) {
            _fakeDB = _fakeDB.filter((comment) => comment.postId !== postId);
        }
    };
}
exports.FakeCommentRepo = FakeCommentRepo;
//# sourceMappingURL=repository.js.map