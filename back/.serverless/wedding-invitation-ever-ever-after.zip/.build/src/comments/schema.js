"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.commentSchema = void 0;
const zod_1 = require("zod");
const schema_1 = require("../posts/schema");
exports.commentSchema = zod_1.z.object({
    id: zod_1.z.number(),
    message: zod_1.z.string().min(1),
    postId: schema_1.postSchema.shape.id
});
//# sourceMappingURL=schema.js.map