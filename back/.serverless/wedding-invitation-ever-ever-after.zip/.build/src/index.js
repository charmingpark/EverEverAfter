"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.appRouter = void 0;
const tslib_1 = require("tslib");
const trpc = tslib_1.__importStar(require("@trpc/server"));
const router_1 = require("./comments/router");
const router_2 = require("./posts/router");
const user_1 = require("./users/user");
exports.appRouter = trpc
    .router()
    .merge('post.', router_2.postRouter)
    .merge('comment.', router_1.commentRouter)
    .merge('user.', user_1.userRouter);
//# sourceMappingURL=index.js.map