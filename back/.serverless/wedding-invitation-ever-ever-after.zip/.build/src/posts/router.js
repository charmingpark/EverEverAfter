"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postRouter = void 0;
const zod_1 = require("zod");
const createRouter_1 = require("../createRouter");
const schema_1 = require("./schema");
exports.postRouter = (0, createRouter_1.createRouter)()
    .query('all', {
    output: zod_1.z.array(schema_1.postSchema),
    async resolve({ ctx }) {
        return ctx.postRepo.all();
    },
})
    .mutation('create', {
    input: schema_1.postSchema.omit({ id: true }),
    async resolve({ input, ctx }) {
        return ctx.postRepo.add(input);
    },
})
    .mutation('delete', {
    input: zod_1.z.object({
        targetId: zod_1.z.number(),
    }),
    async resolve({ input, ctx }) {
        await ctx.commentRepo.deleteCommentsInPost(input.targetId);
        return ctx.postRepo.delete(input.targetId);
    },
})
    .mutation('modify', {
    input: zod_1.z.object({
        targetId: zod_1.z.number(),
        newMessage: zod_1.z.string(),
    }),
    async resolve({ input, ctx }) {
        return ctx.postRepo.modify(input);
    },
});
//# sourceMappingURL=router.js.map