"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createContext = void 0;
const repository_1 = require("./comments/repository");
const repository_2 = require("./posts/repository");
const postRepo = (0, repository_2.FakePostRepo)([]);
const commentRepo = (0, repository_1.FakeCommentRepo)([]);
async function createContext() {
    return { postRepo, commentRepo };
}
exports.createContext = createContext;
//# sourceMappingURL=createContext.js.map