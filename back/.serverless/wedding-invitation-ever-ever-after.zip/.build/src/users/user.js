"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userRouter = void 0;
const tslib_1 = require("tslib");
const trpc = tslib_1.__importStar(require("@trpc/server"));
const zod_1 = require("zod");
const userSchema = zod_1.z.object({ name: zod_1.z.string().min(5) });
let fakeDB = [];
exports.userRouter = trpc
    .router()
    .query('get', {
    async resolve() {
        return fakeDB;
    },
})
    .mutation('create', {
    input: userSchema,
    async resolve({ input }) {
        fakeDB = [...fakeDB, input];
        console.log('fakeDB', fakeDB);
    },
})
    .mutation('clear', {
    input: zod_1.z.object({}),
    async resolve() {
        fakeDB = [];
    },
});
//# sourceMappingURL=user.js.map