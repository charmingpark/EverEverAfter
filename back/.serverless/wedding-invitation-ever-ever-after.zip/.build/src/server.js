"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_lambda_1 = require("@trpc/server/adapters/aws-lambda");
const createContext_1 = require("./createContext");
const _1 = require(".");
exports.handler = (0, aws_lambda_1.awsLambdaRequestHandler)({
    router: _1.appRouter,
    createContext: createContext_1.createContext,
});
//# sourceMappingURL=server.js.map